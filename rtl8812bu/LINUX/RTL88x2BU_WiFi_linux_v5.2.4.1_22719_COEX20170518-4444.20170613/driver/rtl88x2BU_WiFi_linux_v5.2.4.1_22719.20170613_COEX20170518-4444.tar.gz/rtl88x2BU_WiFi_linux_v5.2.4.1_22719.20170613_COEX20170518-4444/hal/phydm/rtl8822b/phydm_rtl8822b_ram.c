//alex temp disable for merge, 20160328
//#include "phydm_precomp.h"

//__iram_odm_func__ void phydm_InitFuncPtrTableRAM8822B(void){


//}